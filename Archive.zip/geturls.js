document.addEventListener('DOMContentLoaded', function () {

    chrome.tabs.query({}, function (tabs) {
        for (var i = 0; i < tabs.length; i++) {
            var tabUrl = tabs[i].url;
            $("<li/>").appendTo("#urls").html("<b>"+tabs[i].title+"</b>");
            $("<li class='withmargin'/>").appendTo("#urls").html("<a id='tab"+i+"'>"+tabUrl+"</a>");
            $("#tab"+i).mouseover(function(){
                //chrome.tabs.highlight({tabs:[i]},function(window){console.log("highlight");});
            });
        }

    });
});
